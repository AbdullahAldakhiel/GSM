<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->type == "Admin"): ?>
                    Welcome To Your Page!!!!!
                    <div class="card">
                            <h5 class="card-header">Global Oil Price</h5>
                            <div class="card-body">
                          <h5>Global oil barrel price : </h5><p id="oilprice"></p>
                          <h5>Last update : </h5> <p id="oildate"></p>
                          <hr>
                          <a href="/SendGasoline/create"><p> <button type="button"  class="btn btn-success" >Calculate the price</button> </p></a>

 

                            </div>
                          </div>
                          <table class="table table-striped">
                              <tr>
                                  <th>Old prices</th>
                                  <th></th>
                                  <th></th>
                              </tr>
                              <?php if(count($SendGasolinePrices) > 0): ?>
                              <?php $__currentLoopData = $SendGasolinePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SendGasolinePrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                    <th><?php echo e($SendGasolinePrice->premiumOctane); ?></th>
                                    <th><?php echo e($SendGasolinePrice->normalOctane); ?></th>
                                    <th><?php echo e($SendGasolinePrice->diesel); ?></th>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <th>
                                  No Prices ..
                              </th>
                              <?php endif; ?>
                          </table>
                          
                          <?php else: ?> 
                          
                          Hello <?php echo e(Auth::user()->name); ?>

                          <table class="table table-striped">
                              <thead>
                              <tr>
                                  <th>New prices</th>
                                  <th>Updated at:    </th>
                                  <th> <?php echo e($SendGasolinePrices->last()->updated_at); ?></th>
                                  </tr>
                          <hr>
                          </thead>
                          <tbody>
                          <tr>
                                  <th>95</th>
                                  <th>91</th>
                                  <th>Diesel</th>
                        </tr>
                        <tr>
                              
                              <th> <?php echo e($SendGasolinePrices->last()->premiumOctane); ?></th>
                              <th>  <?php echo e($SendGasolinePrices->last()->normalOctane); ?></th>
                              <th> <?php echo e($SendGasolinePrices->last()->diesel); ?></th>
</tr>
</tbody>
                 
                          </table>
                          <?php endif; ?>
                         
                </div>
            </div>
        </div>
    </div>
</div>
<script>
 
 function httpGet(){
    var xmlHttp = new XMLHttpRequest();
    
    xmlHttp.open( "GET", "https://api.oilpriceapi.com/v1/prices/latest", false ); // false for synchronous request
    xmlHttp.setRequestHeader("Authorization","Token fda51e339029aa2c0265d9e9877cd7bd");
    xmlHttp.setRequestHeader("Content-Type","application/json");
    xmlHttp.send(null);
     var obj = JSON.parse(xmlHttp.responseText);

     oilcreated = obj.data.created_at;
     oildate = oilcreated.substring(0, 9);
     oiltime = oilcreated.substring(11, 19);
    document.getElementById("oilprice").innerHTML  = (obj.data.price*3.75).toFixed(2);
         document.getElementById("oildate").innerHTML  = oildate + " "+ oiltime;

    }
    window.addEventListener("load", httpGet);

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/GSM/resources/views/dashboard.blade.php ENDPATH**/ ?>