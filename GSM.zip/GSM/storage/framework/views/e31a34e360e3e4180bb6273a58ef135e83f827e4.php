
<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
        <h1>Send New Prices to GasStations</h1>
        <?php echo Form::open(['action' => 'SendGasolineController@store', 'method' => 'POST']); ?>

            <div class="form-group">
            
                <?php echo e(Form::label('premiumOctane', 'PremiumOctane')); ?>

                <input id="premp" class="form-control" readonly="readonly" name="premiumOctane" type="text" value="">

                <?php echo e(Form::label('normalOctane', 'NormalOctane')); ?>

                <input id="nomlp" class="form-control" readonly="readonly" name="normalOctane" type="text" value="">

                <?php echo e(Form::label('diesel', 'Diesel')); ?>

                <input id="diselp" class="form-control" readonly="readonly" name="diesel" type="text" value="">

                <br>
                
               <p> <?php echo e(Form::submit('Update Prices!', ['class' => 'btn btn-primary'])); ?> </p>
            </div>
    <?php echo Form::close(); ?>

        
</div>
 
<script>
 
 function httpGet(){
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", "https://api.oilpriceapi.com/v1/prices/latest", false ); // false for synchronous request
    xmlHttp.setRequestHeader("Authorization","Token fda51e339029aa2c0265d9e9877cd7bd");
    xmlHttp.setRequestHeader("Content-Type","application/json");
    xmlHttp.send(null);
    var obj = JSON.parse(xmlHttp.responseText);

    var prem = (obj.data.price*3.75)/108;
    var noml = (obj.data.price*3.75)/159;
    var des = (obj.data.price*3.75)/497;
    document.getElementById("premp").value  = prem.toFixed(2);
    document.getElementById("nomlp").value  = noml.toFixed(2);

     document.getElementById("diselp").value  = des.toFixed(2);

    }
    window.addEventListener("load", httpGet);

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/GSM/resources/views/SendGasoline/create.blade.php ENDPATH**/ ?>