
<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
        <h1>  <?php echo e($title); ?>  </h1>
        <p> <button type="button" class="btn btn-success">Get Prices!</button> </p>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/GSM/resources/views/pages/index.blade.php ENDPATH**/ ?>