
<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
        <h1>Send New Prices to GasStations</h1>
        <?php if(count($postsGasoline) >= 1): ?>
            <?php $__currentLoopData = $postsGasoline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postGasoline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-body bg-light">
                    <h3>95 : <?php echo e($postGasoline->premiumOctane); ?> , 91 : <?php echo e($postGasoline->normalOctane); ?> , Diesel : <?php echo e($postGasoline->diesel); ?></h3>
                    <small>Updated on : <?php echo e($postGasoline->created_at); ?></small>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php echo e($postsGasoline->links()); ?>

        <?php else: ?>
        <p>Prices has not been sent </p>

        <?php endif; ?>
        <p> <button type="button" class="btn btn-success">Get Prices!</button> </p>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/GSM/resources/views/SendGasoline/index.blade.php ENDPATH**/ ?>