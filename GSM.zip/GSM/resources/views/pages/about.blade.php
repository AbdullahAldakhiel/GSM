@extends('layouts.app')
@section('content')
<h1>  Welcome To GasStation about </h1>
@endsection
