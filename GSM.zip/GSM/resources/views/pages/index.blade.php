@extends('layouts.app')
@section('content')
<div class="jumbotron text-center">
        <h1>  {{$title}}  </h1>
        <p> <button type="button" class="btn btn-success">Get Prices!</button> </p>
</div>

@endsection

