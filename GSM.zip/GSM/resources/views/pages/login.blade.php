@extends('layouts.app')
@section('content')
<h1>  Welcome To GasStation  login</h1>
<p> </p>
<a href="/SendGasoline"><button type="button" class="btn btn-success">get in!</button> </a>
@endsection
