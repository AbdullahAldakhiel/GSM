@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if(Auth::user()->type == "Admin")
                    Welcome To Your Page!!!!!
                    <div class="card">
                            <h5 class="card-header">Global Oil Price</h5>
                            <div class="card-body">
                          <h5>Global oil barrel price : </h5><p id="oilprice"></p>
                          <h5>Last update : </h5> <p id="oildate"></p>
                          <hr>
                          <a href="/SendGasoline/create"><p> <button type="button"  class="btn btn-success" >Calculate the price</button> </p></a>

 

                            </div>
                          </div>
                          <table class="table table-striped">
                              <tr>
                                  <th>Old prices</th>
                                  <th></th>
                                  <th></th>
                              </tr>
                              @if(count($SendGasolinePrices) > 0)
                              @foreach ($SendGasolinePrices as $SendGasolinePrice)
                              <tr>
                                    <th>{{$SendGasolinePrice->premiumOctane}}</th>
                                    <th>{{$SendGasolinePrice->normalOctane}}</th>
                                    <th>{{$SendGasolinePrice->diesel}}</th>
                                </tr>
                              @endforeach
                              @else
                              <th>
                                  No Prices ..
                              </th>
                              @endif
                          </table>
                          
                          @else 
                          
                          Hello {{Auth::user()->name }}
                          <table class="table table-striped">
                              <thead>
                              <tr>
                                  <th>New prices</th>
                                  <th>Updated at:    </th>
                                  <th> {{$SendGasolinePrices->last()->updated_at}}</th>
                                  </tr>
                          <hr>
                          </thead>
                          <tbody>
                          <tr>
                                  <th>95</th>
                                  <th>91</th>
                                  <th>Diesel</th>
                        </tr>
                        <tr>
                              
                              <th> {{$SendGasolinePrices->last()->premiumOctane}}</th>
                              <th>  {{$SendGasolinePrices->last()->normalOctane}}</th>
                              <th> {{$SendGasolinePrices->last()->diesel}}</th>
</tr>
</tbody>
                 
                          </table>
                          @endif
                         
                </div>
            </div>
        </div>
    </div>
</div>
<script>
 
 function httpGet(){
    var xmlHttp = new XMLHttpRequest();
    
    xmlHttp.open( "GET", "https://api.oilpriceapi.com/v1/prices/latest", false ); // false for synchronous request
    xmlHttp.setRequestHeader("Authorization","Token fda51e339029aa2c0265d9e9877cd7bd");
    xmlHttp.setRequestHeader("Content-Type","application/json");
    xmlHttp.send(null);
     var obj = JSON.parse(xmlHttp.responseText);

     oilcreated = obj.data.created_at;
     oildate = oilcreated.substring(0, 9);
     oiltime = oilcreated.substring(11, 19);
    document.getElementById("oilprice").innerHTML  = (obj.data.price*3.75).toFixed(2);
         document.getElementById("oildate").innerHTML  = oildate + " "+ oiltime;

    }
    window.addEventListener("load", httpGet);

</script>
@endsection
