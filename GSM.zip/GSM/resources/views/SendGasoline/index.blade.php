@extends('layouts.app')
@section('content')
<div class="jumbotron text-center">
        <h1>Send New Prices to GasStations</h1>
        @if(count($postsGasoline) >= 1)
            @foreach($postsGasoline as $postGasoline)
                <div class="card card-body bg-light">
                    <h3>95 : {{$postGasoline->premiumOctane}} , 91 : {{$postGasoline->normalOctane}} , Diesel : {{$postGasoline->diesel}}</h3>
                    <small>Updated on : {{$postGasoline->created_at}}</small>
                </div>
            @endforeach
            {{-- pages --}}
            {{$postsGasoline->links()}}
        @else
        <p>Prices has not been sent </p>

        @endif
        <p> <button type="button" class="btn btn-success">Get Prices!</button> </p>
</div>
 
@endsection