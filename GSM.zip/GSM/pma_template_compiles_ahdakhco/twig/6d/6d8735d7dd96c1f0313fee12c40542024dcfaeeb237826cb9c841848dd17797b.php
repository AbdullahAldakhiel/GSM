<?php

/* config/form_display/tabs_bottom.twig */
class __TwigTemplate_2f8159cadaa811fb0406885622134fafae57cf6a0b17c482d6b35b156fabc583 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "config/form_display/tabs_bottom.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "config/form_display/tabs_bottom.twig", "/usr/local/cpanel/base/3rdparty/phpMyAdmin/templates/config/form_display/tabs_bottom.twig");
    }
}
